package com.isil.impaktoisil;

public class Oferta {
    //ATRIBUTOS
    String Nombre,duracion;
    Producto producto;
    int descuento_condicion;
    boolean metodo_pago;

    //CONSTRUCTOR
    public Oferta(Producto producto, String nombre, String duracion) {

        Nombre = nombre;
        this.duracion = duracion;
    }



    //METODOS


    /*
    CREAR OFERTA
    ELIMINAR OFERTA
    */
}
