package com.isil.impaktoisil;

public abstract class Usuario {
    //ATRIBUTOS
      String nombre, apellido, correo, direccion, distrito, provincia, sexo;
      long dni, ruc;
      int telefono;

    //CONSTRUCTOR

    public Usuario(String nombre, String apellido, String correo, String direccion, String distrito, String provincia, String sexo, long dni, long ruc, int telefono) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
        this.direccion = direccion;
        this.distrito = distrito;
        this.provincia = provincia;
        this.sexo = sexo;
        this.dni = dni;
        this.ruc = ruc;
        this.telefono = telefono;
    }

    public Usuario(String nombre, String apellido, String correo, String direccion, String distrito, String provincia, String sexo, long dni, int telefono) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
        this.direccion = direccion;
        this.distrito = distrito;
        this.provincia = provincia;
        this.sexo = sexo;
        this.dni = dni;
        this.telefono = telefono;
    }


    //GET
    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getCorreo() {
        return correo;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getDistrito() {
        return distrito;
    }

    public String getProvincia() {
        return provincia;
    }

    public String getSexo() {
        return sexo;
    }

    public long getDni() {
        return dni;
    }

    public long getRuc() {
        return ruc;
    }

    public int getTelefono() {
        return telefono;
    }

    //METODOS
    public String obtenerDatos(){
        return "Nombre: "+ nombre + "\n"+
               "Apellido: "+ apellido + "\n" +
               "Correo: "+ correo + "\n" ;

    }


}
