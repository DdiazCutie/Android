package com.isil.impaktoisil;

public class Tienda {

    //ATRIBUTOS
    String nombre, direccion, horario;
    int aforo,codigo, monto_acumulado;
    static double igv = 0.18;

    //, cliente

    //CONSTRUCTOR
    public Tienda(String nombre, String direcicon, int codigo) {
        this.nombre = nombre;
        this.direccion = direcicon;
        this.horario = horario;
        this.codigo = codigo;
        horario = "8:00-19:00";
        aforo = 20;
    }

    public Tienda(String nombre, String direccion, String horario, int codigo, int aforo) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.horario = horario;
        this.codigo = codigo;
        this.aforo = aforo;
    }

    public String getNombre() {
        return nombre;
    }

    //GET


    public String getDireccion() {
        return direccion;
    }

    public String getHorario() {
        return horario;
    }

    public int getAforo() {
        return aforo;
    }

    public int getCodigo() {
        return codigo;
    }

    //METODOS
    public void Venta(Producto producto){
        monto_acumulado += producto.precio;
        producto.Stock -= 1;
    }

    String MostrarInfoDia(){
        return  "CodigoTienda:"+ codigo + "\n" +
                "Tienda: "+nombre + "\n"+
                "Dirección: "+ direccion + "\n"+
                "Horario: "+horario + "\n" +
                "Acumulado en Caja: S/."+ monto_acumulado + "\n" +
                "IGV Acumulado: S/. "+monto_acumulado*igv;
    }



    /*
    VENTA
    INVENTARIO
    */







}
