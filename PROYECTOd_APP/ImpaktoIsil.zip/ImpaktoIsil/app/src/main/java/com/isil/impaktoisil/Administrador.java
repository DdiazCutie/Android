package com.isil.impaktoisil;

public class Administrador extends Usuario {
    //ATRIBUTOS
    private int codigoAdmin;
    //CONSTRUCTOR
    public Administrador(int codAdmin, String nombre, String apellido, String correo, String direccion, String distrito,
                  String provincia, String sexo, long dni, long ruc, int telefono) {
        super(nombre, apellido, correo, direccion, distrito, provincia, sexo, dni, ruc, telefono);
        this.codigoAdmin = codAdmin;
    }

    //GET


    public int getCodigoAdmin() {
        return codigoAdmin;
    }

    //METODOS
    public String obtenerDatos(){
        return  "CodigoAdmin: "+codigoAdmin +"\n"+
                "Nombre: "+ nombre + "\n"+
                "Apellido: "+ apellido + "\n" +
                "Correo: "+ correo + "\n"+
                "RUC: " + ruc;
    }
}
