package com.isil.impaktoisil;

import android.telecom.Call;

import java.sql.CallableStatement;
import java.util.ArrayList;

public class Producto {

    //ATRIBUTOS
    static int igv;
    String nombre,fabricante,modelo,categoria,descripcion,img;
    long codigo;
    double precio;
    int cantidadComprado,Stock;

    //CONSTRUCTOR
    public Producto(String nombre, String fabricante, String modelo, String categoria, long codigo, double precio, String descripcion) {
        this.nombre = nombre;
        this.fabricante = fabricante;
        this.modelo = modelo;
        this.categoria = categoria;
        this.codigo = codigo;
        this.precio = precio;
        this.descripcion = descripcion;
    }

    public Producto(String fabricante, String modelo, String categoria, String descripcion, String img, long codigo, double precio, int cantidadComprado, int stock) {
        this.fabricante = fabricante;
        this.modelo = modelo;
        this.categoria = categoria;
        this.descripcion = descripcion;
        this.img = img;
        this.codigo = codigo;
        this.precio = precio;
        this.cantidadComprado = cantidadComprado;
        Stock = stock;
    }

    //METODOS







    /*
    public static ArrayList<Producto> obtenerProducto(){
        ArrayList<Producto> lista = new ArrayList<Producto>();
        try{
            CallableStatement c
        }
    }
    */
    /*
    AGREGAR PRODUCTO
    EDITAR PRODUCTO
    ELIMINAR PRODUCTO
    */










}
