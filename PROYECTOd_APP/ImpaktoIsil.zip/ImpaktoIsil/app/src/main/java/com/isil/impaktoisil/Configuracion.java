package com.isil.impaktoisil;

public class Configuracion {


    Cliente cliente;
    String listaDeseos,invitarAmigo;
    static String contacto;


     //EDITAR USUARIO

    //CONTACTO


    // INVITAR AMIGO
}
