package com.isil.impaktoisil;

public class Estadistica {
    //ATRIBUTOS
    Tienda tienda;
    Tienda monto_acumulado;
    int monto_semanal,monto_quincenal,monto_mensual;

    //CONSTRUCTOR

    public Estadistica(Tienda tienda, Tienda monto_acumulado, int monto_semanal, int monto_quincenal, int monto_mensual) {
        this.tienda = tienda;
        this.monto_acumulado = monto_acumulado;
        this.monto_semanal = monto_semanal;
        this.monto_quincenal = monto_quincenal;
        this.monto_mensual = monto_mensual;
    }

    public Estadistica(Tienda tienda, Tienda monto_acumulado, int monto_semanal) {
        this.tienda = tienda;
        this.monto_acumulado = monto_acumulado;
        this.monto_semanal = monto_semanal;
    }


    //METODOS

    /*
    SEMANAL
    QUINCENAL
    MENSUAL
    */







}
