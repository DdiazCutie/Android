package com.isil.impaktoisil;

//@SuppressWarnings("WeakerAccess")

public class Catalogo {

     String nombre;
     Producto categoria;
     int cantidad;


    public Catalogo(String nombre, Producto categoria, int cantidad) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.cantidad = cantidad;
    }


    //AGREGAR CATEGORIA






}
