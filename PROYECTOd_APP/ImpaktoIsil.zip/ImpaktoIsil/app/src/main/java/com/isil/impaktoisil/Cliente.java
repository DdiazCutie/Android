package com.isil.impaktoisil;

public class Cliente extends Usuario {
    //ATRIBUTOS
    private int codCli;
    //CONTRUCTOR
    public Cliente(int codCli, String nombre, String apellido, String correo, String direccion, String distrito,
                   String provincia, String sexo, long dni, int telefono) {
        super(nombre, apellido, correo, direccion, distrito, provincia, sexo, dni, telefono);
        this.codCli= codCli;
    }

    //GET
    public int getCodCli() {
        return codCli;
    }

    //METODOS
    public String obtenerDatos(){
            return  "codCliente: "+ codCli + "\n"+
                    "Nombre: "+ nombre + "\n"+
                    "Apellido: "+ apellido + "\n" +
                    "Correo: "+ correo + "\n"+
                    "DNI: " + dni;
    }
}

    /*
    INICIO DE SESION
    REGISTRAR
    */
























