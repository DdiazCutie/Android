package com.isil.impaktoisil;

public class TarjetaCliente {

    //ATRIBUTOS
    Cliente cliente;
    long numeroTarjeta;
    double monto;

    //CONSTRUCTOR
    public TarjetaCliente(Cliente cliente, long numeroCuenta) {
        this.cliente = cliente;
        this.numeroTarjeta = numeroCuenta;
    }

    public TarjetaCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    //METODOS

    String mensaje = "";
    public void Comprar(Producto producto) {
        if (monto<=0){
            mensaje= "No tiene saldo en su cuenta para realizar la compra";
        }
        monto -=  producto.precio;
    }
}

