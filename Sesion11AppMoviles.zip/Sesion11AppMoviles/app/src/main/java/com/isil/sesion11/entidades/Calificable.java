package com.isil.sesion11.entidades;

public interface Calificable {
    double ObtenerNotaFinal();
    String ObtenerDetalleCondicion();
}
