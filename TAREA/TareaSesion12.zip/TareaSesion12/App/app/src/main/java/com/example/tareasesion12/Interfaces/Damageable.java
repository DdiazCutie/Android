package com.example.tareasesion12.Interfaces;

public interface Damageable {
    double RecibirDaño();
    String VidaCero();
    double TakeDamage();
}
